# TOZA MEVA — Online Store

A real online fruit store: customers browse prices in English, Russian, or
Uzbek, build a cart, and check out right on the website. This is a
**separate system from the Telegram bot** — it has its own cart, its own
checkout, and its own database — but it can send you the same kind of
Telegram notification for every new order if you give it the same bot
token.

## What it does

- Storefront with your 11-item price list, in 3 languages
- Add to cart, adjust quantities, remove items — all saved in the
  visitor's browser so it survives a refresh
- Checkout collects name, phone, delivery or pickup, and address
- Prices are always recalculated on the server — a customer can never
  change a price by editing the page
- Every order is saved to a real database (`store-orders.db`)
- Optional: sends you a Telegram message the instant an order comes in
  (reuses your existing bot token)
- `/admin` — a password-protected page where you see every order and mark
  it new / confirmed / delivered / cancelled

## 1. Install Node.js

Check if you already have it:
```bash
node --version
```
Need `v18` or higher. If you don't have it, download from nodejs.org
(choose the "LTS" version) and install it.

## 2. Install the project

```bash
cd fruit-store
npm install
```

## 3. Configure it

```bash
cp .env.example .env
```

Open `.env` in any text editor and set:

- `ADMIN_USER` / `ADMIN_PASS` — whatever you want, this locks the `/admin`
  order list so strangers can't see your customers' phone numbers
- `BOT_TOKEN` / `ADMIN_CHAT_ID` — **optional.** If you already made the
  Telegram ordering bot, paste the same values here from that project's
  `.env` file. Then every website order also pings you on Telegram. Leave
  blank if you don't want that.

## 4. Run it

```bash
npm start
```

Open **http://localhost:3000** in your browser — that's your store.

Open **http://localhost:3000/admin** to see incoming orders (it'll prompt
you for the username/password you set in `.env`).

## 5. Try a full order

1. Browse the store, add a couple of fruits to the cart
2. Open the cart, hit checkout
3. Fill in name, phone, choose delivery or pickup
4. Place the order
5. Check `/admin` — your order should appear there (and in Telegram, if
   you set that up)

## 6. Put it online for real (so customers can actually reach it)

**Railway.app** (recommended — free tier, keeps your database file)
1. Push this folder to a GitHub repository
2. On railway.app: New Project → Deploy from GitHub repo
3. In Settings → Variables, add `ADMIN_USER`, `ADMIN_PASS`, and (if using)
   `BOT_TOKEN`, `ADMIN_CHAT_ID` — same values as your `.env`
4. Railway auto-detects `npm start` and deploys
5. You'll get a live URL like `toza-meva.up.railway.app` — that's your
   real website. You can later point your own domain at it in Railway's
   settings.

**A cheap VPS** also works — install Node, copy the folder, `npm install`,
set up the `.env` file, then run it with something that keeps it alive
after you disconnect, e.g.:
```bash
nohup npm start > store.log 2>&1 &
```

## Editing prices

Open `products.js` and edit the `price` field for any fruit — this is the
**only** place prices live; the checkout total is always computed from
here, never trusted from the browser. Restart the server after editing.

To rename a product or change its translation, edit
`public/translations.json` — every language has a `products` section
keyed by the same `id` used in `products.js`.

## Project structure

```
fruit-store/
├── server.js              # Express app — API routes + serves the storefront
├── products.js            # Source of truth for prices — edit this
├── db.js                  # SQLite storage for orders
├── telegram.js            # Sends order notifications via Telegram
├── public/
│   ├── index.html         # The storefront page (single-page app)
│   ├── styles.css
│   ├── app.js              # Cart, checkout, language switching logic
│   └── translations.json  # All storefront text, EN/RU/UZ
├── admin/
│   └── admin.html          # Password-protected order list
├── package.json
└── .env.example
```

## A note on the two systems

You now have two separate ways customers can order:
1. The **Telegram bot** (`fruit-bot` project) — its own database
   (`orders.db`), its own conversation flow
2. This **website** — its own database (`store-orders.db`), its own cart

They don't share a database. If you want a single combined view of every
order regardless of source, the simplest fix later is pointing both at
the same hosted database (e.g. Postgres) instead of two separate SQLite
files — but for a single fruit stall, checking two places (Telegram +
`/admin`) is usually simpler than it sounds.
