require("dotenv").config();
const express = require("express");
const path = require("path");

const { PRODUCTS, PRODUCTS_BY_ID } = require("./products");
const db = require("./db");
const { notifyAdmin } = require("./telegram");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASS = process.env.ADMIN_PASS || "";

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// ---------- public API ----------

app.get("/api/products", (req, res) => {
  res.json(PRODUCTS);
});

app.post("/api/orders", (req, res) => {
  const { customerName, phone, deliveryType, address, items, lang } = req.body || {};

  if (!customerName || typeof customerName !== "string" || !customerName.trim()) {
    return res.status(400).json({ error: "customerName is required" });
  }
  if (!phone || typeof phone !== "string" || !phone.trim()) {
    return res.status(400).json({ error: "phone is required" });
  }
  if (!["delivery", "pickup"].includes(deliveryType)) {
    return res.status(400).json({ error: "deliveryType must be 'delivery' or 'pickup'" });
  }
  if (deliveryType === "delivery" && (!address || !address.trim())) {
    return res.status(400).json({ error: "address is required for delivery orders" });
  }
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: "items must be a non-empty array" });
  }

  // Never trust prices from the browser — look everything up server-side.
  const resolvedItems = [];
  let total = 0;
  for (const item of items) {
    const product = PRODUCTS_BY_ID[item.id];
    const qty = Number(item.qty);
    if (!product || !Number.isFinite(qty) || qty <= 0) {
      return res.status(400).json({ error: `Invalid item: ${JSON.stringify(item)}` });
    }
    const subtotal = product.price * qty;
    total += subtotal;
    resolvedItems.push({ id: product.id, qty, price: product.price, unit: product.unit, subtotal });
  }

  const orderId = db.saveOrder({
    customerName: customerName.trim(),
    phone: phone.trim(),
    deliveryType,
    address: address ? address.trim() : "",
    items: resolvedItems,
    total,
    lang: lang || "ru",
  });

  const itemLines = resolvedItems
    .map((it) => `${it.id} — ${it.qty} ${it.unit} × ${it.price.toLocaleString()} = ${it.subtotal.toLocaleString()}`)
    .join("\n");
  const deliveryLine =
    deliveryType === "delivery" ? `Delivery to: ${address.trim()}` : "Pickup at the stall";

  notifyAdmin(
    `🆕 NEW WEBSITE ORDER #${orderId}\n\n${itemLines}\n\nTotal: ${total.toLocaleString()}\n\n` +
      `Customer: ${customerName.trim()}\nPhone: ${phone.trim()}\n${deliveryLine}`
  );

  res.status(201).json({ orderId, total });
});

// ---------- admin panel (Basic Auth protected) ----------

function requireAdminAuth(req, res, next) {
  if (!ADMIN_PASS) {
    return res
      .status(503)
      .send("Admin panel is disabled: set ADMIN_PASS in your .env file to enable it.");
  }
  const header = req.headers.authorization || "";
  const [scheme, encoded] = header.split(" ");
  if (scheme === "Basic" && encoded) {
    const [user, pass] = Buffer.from(encoded, "base64").toString().split(":");
    if (user === ADMIN_USER && pass === ADMIN_PASS) {
      return next();
    }
  }
  res.set("WWW-Authenticate", 'Basic realm="TOZA MEVA Admin"');
  return res.status(401).send("Authentication required.");
}

app.get("/admin", requireAdminAuth, (req, res) => {
  res.sendFile(path.join(__dirname, "admin", "admin.html"));
});

app.get("/api/admin/orders", requireAdminAuth, (req, res) => {
  res.json(db.getAllOrders());
});

app.get("/api/admin/stats/today", requireAdminAuth, (req, res) => {
  res.json(db.getTodayStats());
});

app.post("/api/admin/orders/:id/status", requireAdminAuth, (req, res) => {
  const { status } = req.body || {};
  if (!["new", "confirmed", "delivered", "cancelled"].includes(status)) {
    return res.status(400).json({ error: "Invalid status" });
  }
  db.updateOrderStatus(req.params.id, status);
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`TOZA MEVA store running at http://localhost:${PORT}`);
  if (!ADMIN_PASS) {
    console.log("Note: ADMIN_PASS is not set — /admin panel is disabled until you set it in .env");
  }
});
