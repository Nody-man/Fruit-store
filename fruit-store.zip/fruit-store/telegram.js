// Sends a plain-text message to the shop's Telegram chat whenever a new
// website order comes in. Uses the same BOT_TOKEN / ADMIN_CHAT_ID you may
// already have from the Telegram ordering bot — one bot can happily send
// messages on behalf of two different systems.
//
// If BOT_TOKEN / ADMIN_CHAT_ID aren't set, this quietly does nothing so the
// store still works without Telegram configured.

async function notifyAdmin(text) {
  const token = process.env.BOT_TOKEN;
  const chatId = process.env.ADMIN_CHAT_ID;
  if (!token || !chatId) {
    console.log("[telegram] BOT_TOKEN / ADMIN_CHAT_ID not set — skipping notification");
    return;
  }
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text }),
    });
    if (!res.ok) {
      const body = await res.text();
      console.error("[telegram] Failed to notify admin:", res.status, body);
    }
  } catch (err) {
    console.error("[telegram] Error notifying admin:", err.message);
  }
}

module.exports = { notifyAdmin };
