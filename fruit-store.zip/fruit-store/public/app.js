(() => {
  const state = {
    lang: localStorage.getItem("tm_lang") || "ru",
    products: [],
    translations: null,
    cart: JSON.parse(localStorage.getItem("tm_cart") || "{}"),
    qtyDraft: {}, // per-product quantity picked before "add to cart" is pressed
  };

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  function t(key) {
    const dict = state.translations[state.lang] || state.translations.ru;
    return dict[key] !== undefined ? dict[key] : key;
  }

  function productName(id) {
    const dict = state.translations[state.lang] || state.translations.ru;
    return (dict.products && dict.products[id]) || id;
  }

  function unitName(unit) {
    return unit === "kg" ? t("unit_kg") : t("unit_pc");
  }

  function formatPrice(n) {
    return n.toLocaleString("en-US").replace(/,/g, " ");
  }

  function saveCart() {
    localStorage.setItem("tm_cart", JSON.stringify(state.cart));
  }

  function cartCount() {
    return Object.values(state.cart).reduce((sum, qty) => sum + qty, 0);
  }

  function cartLines() {
    const lines = [];
    let total = 0;
    for (const [id, qty] of Object.entries(state.cart)) {
      const product = state.products.find((p) => p.id === id);
      if (!product) continue;
      const subtotal = product.price * qty;
      total += subtotal;
      lines.push({ id, qty, product, subtotal });
    }
    return { lines, total };
  }

  function showToast(msg) {
    const toast = $("#toast");
    toast.textContent = msg;
    toast.classList.add("show");
    clearTimeout(window._toastTimer);
    window._toastTimer = setTimeout(() => toast.classList.remove("show"), 2000);
  }

  // ---------- rendering ----------

  function applyStaticTranslations() {
    document.documentElement.lang = state.lang;
    $$("[data-i18n]").forEach((el) => {
      el.textContent = t(el.getAttribute("data-i18n"));
    });
    $$("[data-i18n-placeholder]").forEach((el) => {
      el.placeholder = t(el.getAttribute("data-i18n-placeholder"));
    });
    $$(".lang-switch button").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.lang === state.lang);
    });
  }

  function renderPriceGrid() {
    const grid = $("#price-grid");
    grid.innerHTML = "";
    state.products.forEach((p) => {
      const draftQty = state.qtyDraft[p.id] || 1;
      const card = document.createElement("div");
      card.className = "price-card";
      card.innerHTML = `
        <div class="price-emoji">${p.emoji}</div>
        <div class="price-name">${productName(p.id)}</div>
        <div class="price-value">${formatPrice(p.price)} <span style="font-size:0.65rem;font-weight:500;">${t("currency")}</span></div>
        <div class="price-unit">/ ${unitName(p.unit)}</div>
        <div class="price-controls">
          <div class="qty-stepper">
            <button type="button" class="qty-dec" aria-label="minus">−</button>
            <span class="qty-value">${draftQty}</span>
            <button type="button" class="qty-inc" aria-label="plus">+</button>
          </div>
          <button type="button" class="price-add" data-id="${p.id}">${t("add_to_cart")}</button>
        </div>
      `;
      card.querySelector(".qty-dec").addEventListener("click", () => {
        state.qtyDraft[p.id] = Math.max(1, draftQty - 1);
        renderPriceGrid();
      });
      card.querySelector(".qty-inc").addEventListener("click", () => {
        state.qtyDraft[p.id] = draftQty + 1;
        renderPriceGrid();
      });
      card.querySelector(".price-add").addEventListener("click", (e) => {
        addToCart(p.id, draftQty);
        const btn = e.currentTarget;
        btn.classList.add("added");
        btn.textContent = t("in_cart");
        setTimeout(() => {
          btn.classList.remove("added");
          btn.textContent = t("add_to_cart");
        }, 1000);
        state.qtyDraft[p.id] = 1;
      });
      grid.appendChild(card);
    });
  }

  function renderCartBadge() {
    $("#cart-count").textContent = cartCount();
  }

  function renderCartView() {
    const { lines, total } = cartLines();
    const list = $("#cart-list");
    const emptyState = $("#cart-empty-state");
    const summary = $("#cart-summary");

    if (lines.length === 0) {
      list.innerHTML = "";
      emptyState.hidden = false;
      summary.hidden = true;
      return;
    }
    emptyState.hidden = true;
    summary.hidden = false;

    list.innerHTML = lines
      .map(
        (line) => `
        <div class="cart-line" data-id="${line.id}">
          <div class="emoji">${line.product.emoji}</div>
          <div class="info">
            <div class="name">${productName(line.id)}</div>
            <div class="unit-price">${line.qty} ${unitName(line.product.unit)} × ${formatPrice(line.product.price)} ${t("currency")}</div>
          </div>
          <div class="subtotal">${formatPrice(line.subtotal)}</div>
          <button class="remove-btn" data-id="${line.id}">${t("remove")}</button>
        </div>
      `
      )
      .join("");

    $$(".remove-btn").forEach((btn) =>
      btn.addEventListener("click", () => {
        delete state.cart[btn.dataset.id];
        saveCart();
        renderCartBadge();
        renderCartView();
      })
    );

    $("#cart-total-value").textContent = `${formatPrice(total)} ${t("currency")}`;
  }

  function renderOrderReview() {
    const { lines, total } = cartLines();
    const box = $("#order-review");
    box.innerHTML =
      lines
        .map(
          (line) => `
        <div class="review-line">
          <span>${line.product.emoji} ${productName(line.id)} × ${line.qty}</span>
          <span>${formatPrice(line.subtotal)}</span>
        </div>
      `
        )
        .join("") +
      `<div class="review-total"><span>${t("total")}</span><span>${formatPrice(total)} ${t("currency")}</span></div>`;
  }

  function updateAddressVisibility() {
    const deliveryType = document.querySelector('input[name="delivery"]:checked').value;
    $("#address-field").style.display = deliveryType === "delivery" ? "flex" : "none";
    $("#input-address").required = deliveryType === "delivery";
  }

  // ---------- navigation ----------

  function goTo(view) {
    $$(".view").forEach((v) => (v.hidden = true));
    $(`#view-${view}`).hidden = false;
    if (view === "cart") renderCartView();
    if (view === "checkout") renderOrderReview();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function addToCart(id, qty) {
    state.cart[id] = (state.cart[id] || 0) + qty;
    saveCart();
    renderCartBadge();
  }

  // ---------- checkout submit ----------

  async function handleCheckoutSubmit(e) {
    e.preventDefault();
    const errorBox = $("#checkout-error");
    errorBox.hidden = true;

    const { lines, total } = cartLines();
    const name = $("#input-name").value.trim();
    const phone = $("#input-phone").value.trim();
    const deliveryType = document.querySelector('input[name="delivery"]:checked').value;
    const address = $("#input-address").value.trim();

    if (!name || !phone || (deliveryType === "delivery" && !address) || lines.length === 0) {
      errorBox.textContent = t("error_required");
      errorBox.hidden = false;
      return;
    }

    const submitBtn = $("#place-order-btn");
    submitBtn.disabled = true;
    submitBtn.textContent = t("placing_order");

    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: name,
          phone,
          deliveryType,
          address,
          items: lines.map((l) => ({ id: l.id, qty: l.qty })),
          lang: state.lang,
        }),
      });

      if (!res.ok) throw new Error("order failed");
      const data = await res.json();

      state.cart = {};
      saveCart();
      renderCartBadge();

      $("#confirm-body").textContent = t("confirm_body")
        .replace("{orderId}", data.orderId)
        .replace("{phone}", phone);
      goTo("confirm");
      e.target.reset();
    } catch (err) {
      errorBox.textContent = t("error_generic");
      errorBox.hidden = false;
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = t("place_order");
    }
  }

  // ---------- init ----------

  async function init() {
    const [products, translations] = await Promise.all([
      fetch("/api/products").then((r) => r.json()),
      fetch("/translations.json").then((r) => r.json()),
    ]);
    state.products = products;
    state.translations = translations;

    applyStaticTranslations();
    renderPriceGrid();
    renderCartBadge();

    $$(".lang-switch button").forEach((btn) => {
      btn.addEventListener("click", () => {
        state.lang = btn.dataset.lang;
        localStorage.setItem("tm_lang", state.lang);
        applyStaticTranslations();
        renderPriceGrid();
        renderCartView();
      });
    });

    $("#cart-btn").addEventListener("click", () => goTo("cart"));
    $$('[data-nav="home"]').forEach((el) => el.addEventListener("click", (e) => { e.preventDefault(); goTo("home"); }));
    $$('[data-nav="cart"]').forEach((el) => el.addEventListener("click", (e) => { e.preventDefault(); goTo("cart"); }));
    $("#checkout-btn").addEventListener("click", () => goTo("checkout"));
    $$('input[name="delivery"]').forEach((el) => el.addEventListener("change", updateAddressVisibility));
    $("#checkout-form").addEventListener("submit", handleCheckoutSubmit);

    updateAddressVisibility();
  }

  init();
})();
