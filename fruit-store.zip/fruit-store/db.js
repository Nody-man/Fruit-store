const Database = require("better-sqlite3");

const DB_PATH = process.env.DB_PATH || "store-orders.db";
const db = new Database(DB_PATH);

db.exec(`
  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    delivery_type TEXT NOT NULL,
    address TEXT,
    items_json TEXT NOT NULL,
    total INTEGER NOT NULL,
    lang TEXT NOT NULL DEFAULT 'ru',
    status TEXT NOT NULL DEFAULT 'new',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  )
`);

function saveOrder({ customerName, phone, deliveryType, address, items, total, lang }) {
  const stmt = db.prepare(`
    INSERT INTO orders (customer_name, phone, delivery_type, address, items_json, total, lang)
    VALUES (@customerName, @phone, @deliveryType, @address, @itemsJson, @total, @lang)
  `);
  const result = stmt.run({
    customerName,
    phone,
    deliveryType,
    address: address || "",
    itemsJson: JSON.stringify(items),
    total,
    lang,
  });
  return result.lastInsertRowid;
}

function getAllOrders(limit = 200) {
  const rows = db
    .prepare("SELECT * FROM orders ORDER BY id DESC LIMIT ?")
    .all(limit);
  return rows.map((r) => ({ ...r, items: JSON.parse(r.items_json) }));
}

function getTodayStats() {
  const row = db
    .prepare(
      "SELECT COUNT(*) as count, COALESCE(SUM(total),0) as total FROM orders WHERE date(created_at) = date('now')"
    )
    .get();
  return row;
}

function updateOrderStatus(orderId, status) {
  db.prepare("UPDATE orders SET status = ? WHERE id = ?").run(status, orderId);
}

module.exports = { saveOrder, getAllOrders, getTodayStats, updateOrderStatus };
